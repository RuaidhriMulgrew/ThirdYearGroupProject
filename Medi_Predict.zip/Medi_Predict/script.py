import numpy as np
import pandas as pd
import joblib
from sklearn import svm
from sklearn import datasets


def diabetes(age, pregnancies, glucose, bloodPressure, skinThickness, insulin, bmi, dpf):
	
	# Converting inputs from DiabetesActivity.java
	age = int(age)
	pregnancies = int(pregnancies)
	glucose = int(glucose)
	bloodPressure = int(bloodPressure)
	skinThickness = int(skinThickness)
	insulin = int(insulin)
	bmi = float(bmi)
	dpf = float(dpf)


	clf = load("diabetes_model.joblib")

	patientsArray = np.array([age, pregnancies, glucose, bloodPressure, skinThickness, insulin, bmi, dpf])

	toCheck = pd.DataFrame(patientsArray, columns=["Age", "Pregnancies", "Glucose", "Blood Pressure", "Skin Thickness", "Insulin", "BMI", "Diabetes Pedigree Function"])

	patientResult = clf.predict(toCheck)


	return patientResult

