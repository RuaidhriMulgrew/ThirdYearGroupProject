package com.example.groupprojectpatientinfo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class DiabetesActivity extends AppCompatActivity {

    EditText editPregnancies;
    EditText editGlucose;
    EditText editBloodPressure;
    EditText editSkinThickness;
    EditText editInsulin;
    EditText editBMI;
    EditText editDPF;
    EditText editAge;

    Button btnSubmit;
    TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diabetes);

        editAge = findViewById(R.id.editTextNumAge);
        editPregnancies = findViewById(R.id.editTextNumPregnancies);
        editGlucose = findViewById(R.id.editTextNumGlucose);
        editBloodPressure = findViewById(R.id.editTextNumBloodPressure);
        editSkinThickness = findViewById(R.id.editTextNumSkinThickness);
        editInsulin = findViewById(R.id.editTextNumInsulin);
        editBMI = findViewById(R.id.editTextNumDecBMI);
        editDPF = findViewById(R.id.editTextNumberDecDPF);



        btnSubmit = findViewById(R.id.buttonSubmit);
        result = (TextView) findViewById(R.id.tvResult);

        if(!Python.isStarted()){
            Python.start(new AndroidPlatform(this));
        }

        Python py = Python.getInstance();
        final PyObject pyobj = py.getModule("script");


        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                int age = Integer.parseInt(editAge.getText().toString());
//                int pregnancies = Integer.parseInt(editPregnancies.getText().toString());
//                int glucose = Integer.parseInt(editGlucose.getText().toString());
//                int bloodPressure = Integer.parseInt(editBloodPressure.getText().toString());
//                int skinThickness = Integer.parseInt(editSkinThickness.getText().toString());
//                int insulin = Integer.parseInt(editInsulin.getText().toString());
//                float bmi = Float.parseFloat(editBMI.getText().toString());
//                float diabetespedigreefunction = Float.parseFloat(editDPF.getText().toString());

//                String age = editAge.getText().toString();
//                String pregnancies = editPregnancies.getText().toString();
//                String glucose = editGlucose.getText().toString();
//                String bloodPressure = editBloodPressure.getText().toString();
//                String skinThickness = editSkinThickness.getText().toString();
//                String insulin = editInsulin.getText().toString();
//                String bmi = editBMI.getText().toString();
//                String diabetespedigreefunction = editDPF.getText().toString();

//                int strAge = Integer.parseInt(editAge.getText().toString());

//                result.setText("Age: " + age + "\nPregnancies: " + pregnancies + "\nGlucose: " + glucose + "\nBlood Pressure" + bloodPressure + "\nSkin Thickness: " + skinThickness + "\nInsulin: " + insulin + "\nBMI: " + bmi + "\nDiabetes Pedigree Function: " + diabetespedigreefunction);

                PyObject obj = pyobj.callAttr("diabetes", editAge.getText().toString(), editPregnancies.getText().toString(), editGlucose.getText().toString(), editBloodPressure.getText().toString(), editSkinThickness.getText().toString(), editInsulin.getText().toString(), editBMI.getText().toString(), editDPF.getText().toString());

                result.setText(obj.toString());
            }
        });


    }
}